import{l as o,s as r}from"../chunks/CIM95tiM.js";export{o as load_css,r as start};
